import type { RateLimitResult, RateLimitState } from "../types/security.js";
export type { RateLimitResult, RateLimitState };
export declare class InMemoryRateLimiter {
    private readonly maxRequests;
    private readonly windowMs;
    private readonly states;
    constructor(maxRequests: number, windowMs: number);
    check(key: string, now?: number): RateLimitResult;
    reset(key?: string): void;
    cleanupExpired(now?: number): number;
}
//# sourceMappingURL=rate-limit.d.ts.map