const rolePermissions = {
    user: ["chat:read", "chat:write"],
    admin: ["chat:read", "chat:write", "documents:read", "documents:write"],
};
export const authorize = ({ role, permission, }) => rolePermissions[role]?.includes(permission) ?? false;
//# sourceMappingURL=authorization.js.map