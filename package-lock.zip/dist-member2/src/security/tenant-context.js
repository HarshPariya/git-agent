export const createTenantContext = (tenantId, userId) => {
    const normalizedTenantId = tenantId.trim();
    const normalizedUserId = userId.trim();
    (!normalizedTenantId || !normalizedUserId) &&
        (() => {
            throw new Error("Invalid tenant context");
        })();
    return Object.freeze({
        tenantId: normalizedTenantId,
        userId: normalizedUserId,
    });
};
//# sourceMappingURL=tenant-context.js.map