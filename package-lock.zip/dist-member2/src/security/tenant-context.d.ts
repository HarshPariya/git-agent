import type { TenantContext } from "../types/security.js";
export type { TenantContext };
export declare const createTenantContext: (tenantId: string, userId: string) => TenantContext;
//# sourceMappingURL=tenant-context.d.ts.map