import type { AuthorizeRequest, Permission, Role, TenantContext } from "../types/security.js";
export type { AuthorizeRequest, Permission, Role, TenantContext };
export type AuthorizationRequest = AuthorizeRequest;
export declare const authorize: ({ role, permission, }: AuthorizeRequest) => boolean;
//# sourceMappingURL=authorization.d.ts.map