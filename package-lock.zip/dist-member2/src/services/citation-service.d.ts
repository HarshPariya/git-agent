import type { RetrievalResult } from "../retrieval/types.js";
import { type CitationCheckResult } from "../guardrails/citation-check.js";
export declare const verifyAnswerCitations: (answer: string, sources: readonly RetrievalResult[]) => CitationCheckResult;
//# sourceMappingURL=citation-service.d.ts.map