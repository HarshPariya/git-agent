import { verifyCitations, } from "../guardrails/citation-check.js";
export const verifyAnswerCitations = (answer, sources) => verifyCitations({
    answer,
    sources,
});
//# sourceMappingURL=citation-service.js.map