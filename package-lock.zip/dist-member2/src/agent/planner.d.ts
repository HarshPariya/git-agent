import type { AgentAction, AgentPlan, PlanRequest } from "../types/agent.js";
export type { AgentAction, AgentPlan, PlanRequest };
export declare const createPlan: ({ question }: PlanRequest) => AgentPlan;
//# sourceMappingURL=planner.d.ts.map