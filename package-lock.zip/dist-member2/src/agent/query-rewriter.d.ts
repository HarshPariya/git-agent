import type { LlmProvider } from "../types/llm.js";
import type { QueryRewriteRequest } from "../types/agent.js";
export type { QueryRewriteRequest };
export declare const createQueryRewriter: (llm: LlmProvider) => {
    rewrite: ({ question, conversationContext, }: QueryRewriteRequest) => Promise<string>;
};
//# sourceMappingURL=query-rewriter.d.ts.map