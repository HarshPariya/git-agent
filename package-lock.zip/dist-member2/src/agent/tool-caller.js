import crypto from "node:crypto";
import { continueWithTools, generateWithTools, } from "../llm/client.js";
import { logger } from "../logging/logger.js";
const MAX_OUTPUT_CHARS = 4000;
const formatToolContent = (result) => {
    const serialized = JSON.stringify(result);
    return serialized.length > MAX_OUTPUT_CHARS
        ? `${serialized.slice(0, MAX_OUTPUT_CHARS)}... [truncated]`
        : serialized;
};
export const toLlmTools = (registry, context) => registry.list(context).map((tool) => ({
    type: "function",
    name: tool.name,
    description: tool.description,
    parameters: tool.parameters,
}));
export const executeTool = async (registry, call, context) => {
    const callId = call.id ?? call.callId ?? `call_${crypto.randomUUID().slice(0, 8)}`;
    try {
        const parsedArgs = JSON.parse(call.arguments || "{}");
        const result = await registry.executeTool(call.name, parsedArgs, context);
        return {
            ...result,
            callId,
        };
    }
    catch (error) {
        return {
            toolName: call.name,
            callId,
            success: false,
            output: undefined,
            error: error instanceof Error ? error.message : "Invalid tool arguments",
            durationMs: 0,
        };
    }
};
const boundMessagesWithoutOrphans = (allMessages) => {
    if (allMessages.length <= 12) {
        return [...allMessages];
    }
    const userMessage = allMessages[0];
    const recentSlice = allMessages.slice(-10);
    let validStartIndex = 0;
    while (validStartIndex < recentSlice.length &&
        recentSlice[validStartIndex]?.role === "tool") {
        validStartIndex++;
    }
    return [userMessage, ...recentSlice.slice(validStartIndex)];
};
export async function runToolCalling({ instructions, input, registry, maxRounds = 12, context, generateLlmWithTools = generateWithTools, continueLlmWithTools = continueWithTools, }) {
    const tools = toLlmTools(registry, context);
    const messages = [
        {
            role: "user",
            content: input,
        },
    ];
    let response = await generateLlmWithTools({
        instructions,
        input,
        tools,
    });
    const executedTools = [];
    const allExecutedResults = [];
    for (let round = 0; response.toolCalls.length > 0 && round < maxRounds; round += 1) {
        messages.push(response.message);
        const outputs = await Promise.all(response.toolCalls.map((call) => executeTool(registry, call, context)));
        for (const output of outputs) {
            allExecutedResults.push(output);
            if (output.success)
                executedTools.push(output.toolName);
        }
        messages.push(...outputs.map((result) => ({
            role: "tool",
            tool_call_id: result.callId,
            content: formatToolContent(result),
        })));
        const bounded = boundMessagesWithoutOrphans(messages);
        try {
            response = await continueLlmWithTools({
                instructions,
                messages: bounded,
                tools,
            });
        }
        catch (err) {
            logger.warn("continueWithTools round failed, ending tool loop", {
                operation: "tool_loop_continue",
                metadata: {
                    round,
                    error: err instanceof Error ? err.message : String(err),
                },
            });
            break;
        }
    }
    const responseText = response.text.trim();
    if (responseText.length > 0) {
        return response;
    }
    // Synthesize exact tool results into the response text if LLM returns empty text
    const formattedOutputs = allExecutedResults
        .filter((res) => res.success && res.output)
        .map((res) => {
        const data = res.output;
        if (typeof data.content === "string" && data.content.trim().length > 0) {
            const ext = String(data.path || "").split(".").pop() || "";
            return `\`\`\`${ext}\n${data.content}\n\`\`\``;
        }
        if (typeof data.message === "string" && data.message.trim().length > 0) {
            return `✅ **${res.toolName}**: ${data.message}`;
        }
        if (typeof data.output === "string" && data.output.trim().length > 0) {
            return `\`\`\`text\n${data.output}\n\`\`\``;
        }
        if (Array.isArray(data.entries)) {
            const header = `### Directory: \`${String(data.path || ".")}\` (${data.totalEntries ?? data.entries.length} items)\n`;
            const list = data.entries
                .map((e) => `- ${e.type === "directory" ? "📁" : "📄"} \`${e.relativePath || e.name}\``)
                .join("\n");
            return `${header}\n${list}`;
        }
        if (Array.isArray(data.results)) {
            return data.results
                .map((r) => `> **[${r.source}${r.page ? ` p.${r.page}` : ""}]**\n${r.content}`)
                .join("\n\n");
        }
        return JSON.stringify(res.output, null, 2);
    })
        .filter(Boolean)
        .join("\n\n");
    const fallbackSummary = formattedOutputs.trim().length > 0
        ? formattedOutputs
        : executedTools.length > 0
            ? `Successfully executed operations using: ${executedTools.join(", ")}.`
            : "Successfully completed requested tool operations.";
    return {
        ...response,
        text: fallbackSummary,
        message: {
            role: "assistant",
            content: fallbackSummary,
            ...(response.message.tool_calls !== undefined && {
                tool_calls: response.message.tool_calls,
            }),
        },
    };
}
export const toolCaller = {
    call: runToolCalling,
};
//# sourceMappingURL=tool-caller.js.map