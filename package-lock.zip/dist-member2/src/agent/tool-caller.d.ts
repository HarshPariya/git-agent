import { continueWithTools, generateWithTools, type LlmTool } from "../llm/client.js";
import type { ToolExecutionContext, ToolExecutionResult } from "../types/tools.js";
import type { ToolLlmResponse } from "../types/llm.js";
import type { ToolRegistry } from "../tools/registry.js";
export interface ToolCallingRequest {
    readonly instructions: string;
    readonly input: string;
    readonly registry: ToolRegistry;
    readonly maxRounds: number;
    readonly context: ToolExecutionContext;
    readonly generateLlmWithTools?: typeof generateWithTools;
    readonly continueLlmWithTools?: typeof continueWithTools;
}
export declare const toLlmTools: (registry: ToolRegistry, context: ToolExecutionContext) => readonly LlmTool[];
export declare const executeTool: (registry: ToolRegistry, call: {
    readonly id?: string;
    readonly callId?: string;
    readonly name: string;
    readonly arguments: string;
}, context: ToolExecutionContext) => Promise<ToolExecutionResult>;
export declare function runToolCalling({ instructions, input, registry, maxRounds, context, generateLlmWithTools, continueLlmWithTools, }: ToolCallingRequest): Promise<ToolLlmResponse>;
export declare const toolCaller: {
    call: typeof runToolCalling;
};
//# sourceMappingURL=tool-caller.d.ts.map