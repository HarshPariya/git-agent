const DEFAULT_CACHE_CONFIG = {
    maxSize: 1000,
    ttlMs: 5 * 60 * 1000,
    enabled: true,
};
export class AgentCache {
    cache = new Map();
    config;
    hits = 0;
    misses = 0;
    constructor(config = {}) {
        this.config = { ...DEFAULT_CACHE_CONFIG, ...config };
    }
    generateKey(context) {
        return `${context.tenantId}:${context.sessionId}:${context.question}`;
    }
    get(context) {
        if (!this.config.enabled)
            return null;
        const key = this.generateKey(context);
        const entry = this.cache.get(key);
        const isExpired = Boolean(entry && Date.now() > entry.expiresAt);
        isExpired && this.cache.delete(key);
        const valid = entry && !isExpired;
        valid ? this.hits++ : this.misses++;
        return valid ? entry.value : null;
    }
    set(context, value) {
        if (!this.config.enabled)
            return;
        const key = this.generateKey(context);
        while (this.cache.size >= this.config.maxSize) {
            const oldest = this.cache.keys().next().value;
            if (!oldest)
                break;
            this.cache.delete(oldest);
        }
        this.cache.set(key, {
            value,
            expiresAt: Date.now() + this.config.ttlMs,
        });
    }
    clear() {
        this.cache.clear();
        this.hits = 0;
        this.misses = 0;
    }
    getStats() {
        const total = this.hits + this.misses;
        return {
            hits: this.hits,
            misses: this.misses,
            hitRate: total > 0 ? this.hits / total : 0,
            size: this.cache.size,
        };
    }
}
export const createAgentCache = (config) => new AgentCache(config);
const DEFAULT_DEDUP_CONFIG = {
    enabled: true,
    timeoutMs: Number(process.env.DEDUPLICATION_TIMEOUT_MS ?? 120_000),
};
export class RequestDeduplicator {
    pending = new Map();
    config;
    constructor(config = {}) {
        this.config = { ...DEFAULT_DEDUP_CONFIG, ...config };
    }
    generateKey(context) {
        return `${context.tenantId}:${context.sessionId}:${context.question}`;
    }
    async execute(context, operation) {
        if (!this.config.enabled)
            return operation();
        const key = this.generateKey(context);
        const existing = this.pending.get(key);
        if (existing)
            return existing;
        let timer;
        try {
            const promise = operation();
            this.pending.set(key, promise);
            const timeoutPromise = new Promise((_, reject) => {
                timer = setTimeout(() => reject(new Error("Deduplication timeout")), this.config.timeoutMs);
            });
            return await Promise.race([promise, timeoutPromise]);
        }
        finally {
            timer && clearTimeout(timer);
            this.pending.delete(key);
        }
    }
    getPendingCount() {
        return this.pending.size;
    }
}
export const createRequestDeduplicator = (config) => new RequestDeduplicator(config);
//# sourceMappingURL=cache.js.map