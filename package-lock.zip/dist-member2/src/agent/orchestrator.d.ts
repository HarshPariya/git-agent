import type { LlmProvider } from "../types/llm.js";
import type { Retriever } from "../retrieval/types.js";
import { ConversationMemory } from "./memory.js";
import type { AgentContext, AgentExecutionResult } from "../types/agent.js";
export declare const buildSystemObservabilityResponse: (question: string) => string;
export declare const createAgent: (memory: ConversationMemory, retriever: Retriever, llm: LlmProvider) => {
    run({ tenantId, sessionId, question, documentIds, retrievalMode, }: AgentContext): Promise<AgentExecutionResult>;
};
//# sourceMappingURL=orchestrator.d.ts.map