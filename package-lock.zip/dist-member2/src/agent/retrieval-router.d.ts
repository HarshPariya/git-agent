export type RetrievalMode = "code" | "document" | "mixed" | "general" | "system";
export interface RouteRequest {
    readonly query: string;
    readonly hasUploadedDocuments?: boolean | undefined;
    readonly documentIds?: readonly string[] | undefined;
}
export interface RouteResult {
    readonly mode: RetrievalMode;
    readonly confidence: number;
    readonly reason: string;
}
export declare function routeQuery({ query, hasUploadedDocuments, }: RouteRequest): RouteResult;
//# sourceMappingURL=retrieval-router.d.ts.map