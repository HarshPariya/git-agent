import type { Memory, Message } from "../types/agent.js";
export type { Memory, Message };
export declare class ConversationMemory implements Memory {
    private readonly maxMessages;
    private readonly conversations;
    constructor(maxMessages?: number);
    private key;
    get(tenantId: string, sessionId: string): readonly Message[];
    add(tenantId: string, sessionId: string, message: Message): void;
    clear(tenantId: string, sessionId: string): void;
}
//# sourceMappingURL=memory.d.ts.map