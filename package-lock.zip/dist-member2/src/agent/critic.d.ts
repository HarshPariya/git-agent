import type { CriticRequest, CriticResult } from "../types/agent.js";
export type { CriticRequest, CriticResult };
export declare const evaluateAnswer: ({ question, answer, context, }: CriticRequest) => CriticResult;
//# sourceMappingURL=critic.d.ts.map