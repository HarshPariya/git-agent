import type { AgentContext, AgentExecutionResult } from "../types/agent.js";
export interface CacheEntry<T> {
    readonly value: T;
    readonly expiresAt: number;
}
export interface AgentCacheConfig {
    readonly maxSize: number;
    readonly ttlMs: number;
    readonly enabled: boolean;
}
export declare class AgentCache {
    private readonly cache;
    private readonly config;
    private hits;
    private misses;
    constructor(config?: Partial<AgentCacheConfig>);
    private generateKey;
    get(context: AgentContext): AgentExecutionResult | null;
    set(context: AgentContext, value: AgentExecutionResult): void;
    clear(): void;
    getStats(): {
        hits: number;
        misses: number;
        hitRate: number;
        size: number;
    };
}
export declare const createAgentCache: (config?: Partial<AgentCacheConfig>) => AgentCache;
export interface RequestDeduplicationConfig {
    readonly enabled: boolean;
    readonly timeoutMs: number;
}
export declare class RequestDeduplicator {
    private readonly pending;
    private readonly config;
    constructor(config?: Partial<RequestDeduplicationConfig>);
    private generateKey;
    execute<T>(context: AgentContext, operation: () => Promise<T>): Promise<T>;
    getPendingCount(): number;
}
export declare const createRequestDeduplicator: (config?: Partial<RequestDeduplicationConfig>) => RequestDeduplicator;
//# sourceMappingURL=cache.d.ts.map