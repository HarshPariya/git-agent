const DEFAULT_MAX_MESSAGES = 20;
export class ConversationMemory {
    maxMessages;
    conversations = new Map();
    constructor(maxMessages = DEFAULT_MAX_MESSAGES) {
        this.maxMessages = maxMessages;
    }
    key(tenantId, sessionId) {
        return `${tenantId}:${sessionId}`;
    }
    get(tenantId, sessionId) {
        return this.conversations.get(this.key(tenantId, sessionId)) ?? [];
    }
    add(tenantId, sessionId, message) {
        const key = this.key(tenantId, sessionId);
        const messages = this.conversations.get(key) ?? [];
        messages.push(message);
        const excess = messages.length - this.maxMessages;
        excess > 0 && messages.splice(0, excess);
        this.conversations.set(key, messages);
    }
    clear(tenantId, sessionId) {
        this.conversations.delete(this.key(tenantId, sessionId));
    }
}
//# sourceMappingURL=memory.js.map