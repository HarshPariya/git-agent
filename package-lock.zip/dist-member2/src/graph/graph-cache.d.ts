import type { ParsedFile } from "../ingestion/parser.js";
import type { GraphEntity } from "./entity-extractor.js";
import type { GraphRelationship } from "./relationship-extractor.js";
export interface GraphCacheData {
    version: number;
    repositoryHash: string;
    createdAt: string;
    entities: GraphEntity[];
    relationships: GraphRelationship[];
}
export declare function computeRepositoryHash(parsedFiles: ParsedFile[]): string;
export declare function loadGraphCache(cachePath?: string): Promise<GraphCacheData | null>;
export declare function saveGraphCache(data: Omit<GraphCacheData, "version" | "createdAt">, cachePath?: string): Promise<void>;
//# sourceMappingURL=graph-cache.d.ts.map