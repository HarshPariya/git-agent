import type { ParsedFile } from "../ingestion/parser.js";
import type { GraphEntity } from "./entity-extractor.js";
export type RelationshipType = "contains" | "imports" | "calls" | "exports";
export interface GraphRelationship {
    id: string;
    type: RelationshipType;
    sourceId: string;
    targetId: string;
    metadata: Record<string, unknown>;
}
export declare function extractRelationshipsFromFile(file: ParsedFile, entities: GraphEntity[]): GraphRelationship[];
export declare function extractRelationships(parsedFiles: ParsedFile[], entities: GraphEntity[]): GraphRelationship[];
//# sourceMappingURL=relationship-extractor.d.ts.map