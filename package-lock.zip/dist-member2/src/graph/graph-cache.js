import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
const CACHE_VERSION = 1;
const DEFAULT_CACHE_PATH = path.join(process.cwd(), ".cache", "graphrag", "graph.json");
export function computeRepositoryHash(parsedFiles) {
    const hash = crypto.createHash("sha256");
    // Sort by filePath for deterministic hash order
    const sorted = [...parsedFiles].sort((a, b) => a.filePath.localeCompare(b.filePath));
    for (const file of sorted) {
        hash.update(file.filePath);
        hash.update(file.content);
    }
    return hash.digest("hex");
}
export async function loadGraphCache(cachePath = DEFAULT_CACHE_PATH) {
    try {
        const raw = await fs.readFile(cachePath, "utf-8");
        const data = JSON.parse(raw);
        if (data.version !== CACHE_VERSION) {
            return null;
        }
        return data;
    }
    catch {
        return null;
    }
}
export async function saveGraphCache(data, cachePath = DEFAULT_CACHE_PATH) {
    try {
        await fs.mkdir(path.dirname(cachePath), { recursive: true });
        const cachePayload = {
            version: CACHE_VERSION,
            repositoryHash: data.repositoryHash,
            createdAt: new Date().toISOString(),
            entities: data.entities,
            relationships: data.relationships,
        };
        await fs.writeFile(cachePath, JSON.stringify(cachePayload, null, 2), "utf-8");
    }
    catch (error) {
        console.warn("⚠ Failed to save graph cache:", error);
    }
}
//# sourceMappingURL=graph-cache.js.map