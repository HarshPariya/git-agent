import path from "node:path";
function normalizeId(value) {
    return value
        .replace(/\\/g, "/")
        .replace(/[^a-zA-Z0-9/_-]/g, "-")
        .toLowerCase();
}
function createFileEntity(file) {
    return {
        id: `file:${normalizeId(file.filePath)}`,
        type: "file",
        name: path.basename(file.filePath),
        filePath: file.filePath,
        startLine: 1,
        endLine: file.content
            ? file.content.split(/\r?\n/).length
            : 1,
        language: file.language,
        metadata: {
            directory: path.dirname(file.filePath),
            imports: file.imports.map((item) => item.source),
        },
    };
}
function createFunctionEntity(file, fn) {
    return {
        id: `function:${normalizeId(file.filePath)}:${normalizeId(fn.name)}:${fn.startLine}`,
        type: "function",
        name: fn.name,
        filePath: file.filePath,
        startLine: fn.startLine,
        endLine: fn.endLine,
        language: file.language,
        metadata: {
            parentFile: file.filePath,
        },
    };
}
function createClassEntity(file, classInfo) {
    return {
        id: `class:${normalizeId(file.filePath)}:${normalizeId(classInfo.name)}:${classInfo.startLine}`,
        type: "class",
        name: classInfo.name,
        filePath: file.filePath,
        startLine: classInfo.startLine,
        endLine: classInfo.endLine,
        language: file.language,
        metadata: {
            parentFile: file.filePath,
        },
    };
}
function createModuleEntities(file) {
    const modules = [];
    for (const importedModule of file.imports) {
        modules.push({
            id: `module:${normalizeId(importedModule.source)}`,
            type: "module",
            name: importedModule.source,
            metadata: {
                importedBy: file.filePath,
            },
        });
    }
    return modules;
}
export function extractEntitiesFromFile(file) {
    const entities = [];
    entities.push(createFileEntity(file));
    for (const fn of file.functions) {
        entities.push(createFunctionEntity(file, fn));
    }
    for (const classInfo of file.classes) {
        entities.push(createClassEntity(file, classInfo));
    }
    entities.push(...createModuleEntities(file));
    return entities;
}
export function extractEntities(parsedFiles) {
    const entityMap = new Map();
    for (const file of parsedFiles) {
        const entities = extractEntitiesFromFile(file);
        for (const entity of entities) {
            if (!entityMap.has(entity.id)) {
                entityMap.set(entity.id, entity);
            }
        }
    }
    return Array.from(entityMap.values());
}
//# sourceMappingURL=entity-extractor.js.map