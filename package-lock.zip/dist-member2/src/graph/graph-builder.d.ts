import type { GraphEntity } from "./entity-extractor.js";
import type { GraphRelationship, RelationshipType } from "./relationship-extractor.js";
export interface CodeGraph {
    nodes: Map<string, GraphEntity>;
    edges: GraphRelationship[];
    outgoing: Map<string, GraphRelationship[]>;
    incoming: Map<string, GraphRelationship[]>;
}
export interface TraverseOptions {
    maxDepth?: number | undefined;
    relationshipTypes?: RelationshipType[] | undefined;
}
export interface TraversalResult {
    entity: GraphEntity;
    depth: number;
    via?: GraphRelationship | undefined;
}
export declare function buildGraph(entities: GraphEntity[], relationships: GraphRelationship[]): CodeGraph;
export declare function getNode(graph: CodeGraph, entityId: string): GraphEntity | undefined;
export declare function getOutgoing(graph: CodeGraph, entityId: string, relationshipTypes?: RelationshipType[]): GraphRelationship[];
export declare function getIncoming(graph: CodeGraph, entityId: string, relationshipTypes?: RelationshipType[]): GraphRelationship[];
export declare function getNeighbors(graph: CodeGraph, entityId: string, relationshipTypes?: RelationshipType[]): GraphEntity[];
export declare function traverseGraph(graph: CodeGraph, startEntityId: string, options?: TraverseOptions): TraversalResult[];
export declare function findEntitiesByName(graph: CodeGraph, name: string): GraphEntity[];
export declare function getGraphStats(graph: CodeGraph): {
    totalNodes: number;
    totalEdges: number;
    entityCounts: {
        [k: string]: number;
    };
    relationshipCounts: {
        [k: string]: number;
    };
};
//# sourceMappingURL=graph-builder.d.ts.map