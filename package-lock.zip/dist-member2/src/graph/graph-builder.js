export function buildGraph(entities, relationships) {
    const nodes = new Map();
    const outgoing = new Map();
    const incoming = new Map();
    for (const entity of entities) {
        nodes.set(entity.id, entity);
    }
    for (const relationship of relationships) {
        if (!outgoing.has(relationship.sourceId)) {
            outgoing.set(relationship.sourceId, []);
        }
        if (!incoming.has(relationship.targetId)) {
            incoming.set(relationship.targetId, []);
        }
        outgoing.get(relationship.sourceId).push(relationship);
        incoming.get(relationship.targetId).push(relationship);
    }
    return {
        nodes,
        edges: relationships,
        outgoing,
        incoming,
    };
}
export function getNode(graph, entityId) {
    return graph.nodes.get(entityId);
}
export function getOutgoing(graph, entityId, relationshipTypes) {
    const edges = graph.outgoing.get(entityId) ?? [];
    if (!relationshipTypes || relationshipTypes.length === 0) {
        return edges;
    }
    return edges.filter((edge) => relationshipTypes.includes(edge.type));
}
export function getIncoming(graph, entityId, relationshipTypes) {
    const edges = graph.incoming.get(entityId) ?? [];
    if (!relationshipTypes || relationshipTypes.length === 0) {
        return edges;
    }
    return edges.filter((edge) => relationshipTypes.includes(edge.type));
}
export function getNeighbors(graph, entityId, relationshipTypes) {
    const neighborIds = new Set();
    const outgoing = getOutgoing(graph, entityId, relationshipTypes);
    const incoming = getIncoming(graph, entityId, relationshipTypes);
    for (const edge of outgoing) {
        neighborIds.add(edge.targetId);
    }
    for (const edge of incoming) {
        neighborIds.add(edge.sourceId);
    }
    const neighbors = [];
    for (const id of neighborIds) {
        const entity = graph.nodes.get(id);
        if (entity) {
            neighbors.push(entity);
        }
    }
    return neighbors;
}
export function traverseGraph(graph, startEntityId, options = {}) {
    const maxDepth = options.maxDepth ?? 2;
    const visited = new Set();
    const results = [];
    const queue = [
        {
            entityId: startEntityId,
            depth: 0,
        },
    ];
    while (queue.length > 0) {
        const current = queue.shift();
        if (visited.has(current.entityId)) {
            continue;
        }
        visited.add(current.entityId);
        const entity = graph.nodes.get(current.entityId);
        if (!entity) {
            continue;
        }
        results.push({
            entity,
            depth: current.depth,
            via: current.via,
        });
        if (current.depth >= maxDepth) {
            continue;
        }
        const outgoing = getOutgoing(graph, current.entityId, options.relationshipTypes);
        const incoming = getIncoming(graph, current.entityId, options.relationshipTypes);
        for (const edge of outgoing) {
            if (!visited.has(edge.targetId)) {
                queue.push({
                    entityId: edge.targetId,
                    depth: current.depth + 1,
                    via: edge,
                });
            }
        }
        for (const edge of incoming) {
            if (!visited.has(edge.sourceId)) {
                queue.push({
                    entityId: edge.sourceId,
                    depth: current.depth + 1,
                    via: edge,
                });
            }
        }
    }
    return results;
}
export function findEntitiesByName(graph, name) {
    const normalized = name.toLowerCase();
    return Array.from(graph.nodes.values()).filter((entity) => entity.name.toLowerCase() === normalized);
}
export function getGraphStats(graph) {
    const entityCounts = new Map();
    const relationshipCounts = new Map();
    for (const entity of graph.nodes.values()) {
        entityCounts.set(entity.type, (entityCounts.get(entity.type) ?? 0) + 1);
    }
    for (const edge of graph.edges) {
        relationshipCounts.set(edge.type, (relationshipCounts.get(edge.type) ?? 0) + 1);
    }
    return {
        totalNodes: graph.nodes.size,
        totalEdges: graph.edges.length,
        entityCounts: Object.fromEntries(entityCounts),
        relationshipCounts: Object.fromEntries(relationshipCounts),
    };
}
//# sourceMappingURL=graph-builder.js.map