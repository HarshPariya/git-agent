import type { ParsedFile } from "../ingestion/parser.js";
export type EntityType = "file" | "function" | "class" | "module";
export interface GraphEntity {
    id: string;
    type: EntityType;
    name: string;
    filePath?: string;
    startLine?: number;
    endLine?: number;
    language?: string;
    metadata: Record<string, unknown>;
}
export declare function extractEntitiesFromFile(file: ParsedFile): GraphEntity[];
export declare function extractEntities(parsedFiles: ParsedFile[]): GraphEntity[];
//# sourceMappingURL=entity-extractor.d.ts.map