import { pool } from "../db/postgres.js";
class MetricsCollector {
    retrievalRequests = 0;
    failedRetrievals = 0;
    totalRetrievalLatencyMs = 0;
    totalVectorLatencyMs = 0;
    totalGraphLatencyMs = 0;
    totalRerankLatencyMs = 0;
    latencySamples = [];
    slowQueries = [];
    repoMetricsMap = new Map();
    dbQueries = 0;
    failedDbQueries = 0;
    cacheHits = 0;
    cacheMisses = 0;
    indexedFiles = 0;
    deletedFiles = 0;
    lastIndexingDurationMs = 0;
    SLOW_QUERY_THRESHOLD_MS = 100;
    recordRetrieval(totalMs, vectorMs, graphMs, rerankMs, success = true, queryText = "", repository = "ai-chatbot") {
        this.retrievalRequests++;
        if (!success) {
            this.failedRetrievals++;
        }
        this.totalRetrievalLatencyMs += totalMs;
        this.totalVectorLatencyMs += vectorMs;
        this.totalGraphLatencyMs += graphMs;
        this.totalRerankLatencyMs += rerankMs;
        this.latencySamples.push(totalMs);
        if (this.latencySamples.length > 1000) {
            this.latencySamples.shift();
        }
        // Record per-repository metrics
        const repoStats = this.repoMetricsMap.get(repository) ?? {
            total: 0,
            failed: 0,
            totalLatencyMs: 0,
        };
        repoStats.total++;
        if (!success)
            repoStats.failed++;
        repoStats.totalLatencyMs += totalMs;
        this.repoMetricsMap.set(repository, repoStats);
        // Record slow query log if latency exceeds threshold
        if (totalMs >= this.SLOW_QUERY_THRESHOLD_MS && queryText) {
            this.slowQueries.push({
                timestamp: new Date().toISOString(),
                query: queryText,
                repository,
                totalMs,
                vectorMs,
                graphMs,
                rerankMs,
            });
            if (this.slowQueries.length > 50) {
                this.slowQueries.shift(); // Keep latest 50 slow queries
            }
        }
    }
    recordDbQuery(success = true) {
        this.dbQueries++;
        if (!success) {
            this.failedDbQueries++;
        }
    }
    recordCacheHit(hit) {
        if (hit) {
            this.cacheHits++;
        }
        else {
            this.cacheMisses++;
        }
    }
    recordRagMetrics(metrics) {
        console.log(`[RAG METRICS] mode: ${metrics.retrievalMode} | retrieved: ${metrics.retrievedCandidates} | reranked: ${metrics.rerankedCandidates} | sentToLLM: ${metrics.sentToLLM} | ragTokens: ${metrics.ragContextTokens} | memTokens: ${metrics.memoryTokens} | totalInputTokens: ${metrics.llmInputTokens}`);
    }
    recordIndexing(indexed, deleted, durationMs) {
        this.indexedFiles += indexed;
        this.deletedFiles += deleted;
        this.lastIndexingDurationMs = durationMs;
    }
    calculatePercentiles() {
        if (this.latencySamples.length === 0) {
            return { p50Ms: 0, p90Ms: 0, p95Ms: 0, p99Ms: 0 };
        }
        const sorted = [...this.latencySamples].sort((a, b) => a - b);
        const getPercentile = (p) => {
            const idx = Math.ceil((p / 100) * sorted.length) - 1;
            return sorted[Math.max(0, idx)] ?? 0;
        };
        return {
            p50Ms: getPercentile(50),
            p90Ms: getPercentile(90),
            p95Ms: getPercentile(95),
            p99Ms: getPercentile(99),
        };
    }
    calculateHealthScore() {
        if (this.retrievalRequests === 0) {
            return {
                status: "EXCELLENT",
                scorePercentage: 100,
                description: "System idle and fully healthy.",
            };
        }
        const failureRate = this.failedRetrievals / this.retrievalRequests;
        const percentiles = this.calculatePercentiles();
        let score = 100 - failureRate * 100 * 2;
        if (percentiles.p95Ms > 200)
            score -= 15;
        if (percentiles.p95Ms > 500)
            score -= 25;
        score = Math.max(0, Math.min(100, Math.round(score)));
        let status = "EXCELLENT";
        if (score < 95)
            status = "GOOD";
        if (score < 80)
            status = "DEGRADED";
        if (score < 50)
            status = "CRITICAL";
        return {
            status,
            scorePercentage: score,
            description: `RAG retrieval SLA health score at ${score}% (${status}). P95 latency: ${percentiles.p95Ms}ms.`,
        };
    }
    getMetrics(embeddingStats) {
        const totalCache = this.cacheHits + this.cacheMisses;
        const hitRatePercent = totalCache > 0
            ? `${((this.cacheHits / totalCache) * 100).toFixed(1)}%`
            : "0.0%";
        const perRepoObj = {};
        for (const [repo, data] of this.repoMetricsMap.entries()) {
            perRepoObj[repo] = {
                repository: repo,
                totalRequests: data.total,
                failedRequests: data.failed,
                avgLatencyMs: data.total > 0 ? Math.round(data.totalLatencyMs / data.total) : 0,
            };
        }
        return {
            healthScore: this.calculateHealthScore(),
            retrieval: {
                totalRequests: this.retrievalRequests,
                failedRequests: this.failedRetrievals,
                totalLatencyMs: this.totalRetrievalLatencyMs,
                avgLatencyMs: this.retrievalRequests > 0
                    ? Math.round(this.totalRetrievalLatencyMs / this.retrievalRequests)
                    : 0,
                percentiles: this.calculatePercentiles(),
                vectorLatencyMs: this.retrievalRequests > 0
                    ? Math.round(this.totalVectorLatencyMs / this.retrievalRequests)
                    : 0,
                graphLatencyMs: this.retrievalRequests > 0
                    ? Math.round(this.totalGraphLatencyMs / this.retrievalRequests)
                    : 0,
                rerankLatencyMs: this.retrievalRequests > 0
                    ? Math.round(this.totalRerankLatencyMs / this.retrievalRequests)
                    : 0,
            },
            database: {
                totalQueries: this.dbQueries,
                failedQueries: this.failedDbQueries,
                poolTotalConnections: pool.totalCount ?? 0,
                poolIdleConnections: pool.idleCount ?? 0,
                poolWaitingCount: pool.waitingCount ?? 0,
            },
            embeddings: {
                modelLoadTimeMs: embeddingStats?.modelLoadTimeMs ?? 0,
                totalEmbeddings: embeddingStats?.totalEmbeddings ?? 0,
                failedEmbeddings: embeddingStats?.failedEmbeddings ?? 0,
                avgLatencyMs: embeddingStats?.averageLatencyMs ?? 0,
            },
            graphCache: {
                hits: this.cacheHits,
                misses: this.cacheMisses,
                hitRate: hitRatePercent,
            },
            indexing: {
                totalIndexedFiles: this.indexedFiles,
                totalDeletedFiles: this.deletedFiles,
                lastIndexingDurationMs: this.lastIndexingDurationMs,
            },
            slowQueries: this.slowQueries,
            perRepository: perRepoObj,
        };
    }
    getPrometheusFormat(embeddingStats) {
        const metrics = this.getMetrics(embeddingStats);
        return [
            `# HELP rag_retrieval_requests_total Total number of retrieval requests`,
            `# TYPE rag_retrieval_requests_total counter`,
            `rag_retrieval_requests_total{status="success"} ${metrics.retrieval.totalRequests - metrics.retrieval.failedRequests}`,
            `rag_retrieval_requests_total{status="failed"} ${metrics.retrieval.failedRequests}`,
            ``,
            `# HELP rag_retrieval_health_score System SLA health percentage`,
            `# TYPE rag_retrieval_health_score gauge`,
            `rag_retrieval_health_score ${metrics.healthScore.scorePercentage}`,
            ``,
            `# HELP rag_retrieval_latency_ms Retrieval latency in milliseconds`,
            `# TYPE rag_retrieval_latency_ms summary`,
            `rag_retrieval_latency_ms{quantile="0.5"} ${metrics.retrieval.percentiles.p50Ms}`,
            `rag_retrieval_latency_ms{quantile="0.9"} ${metrics.retrieval.percentiles.p90Ms}`,
            `rag_retrieval_latency_ms{quantile="0.95"} ${metrics.retrieval.percentiles.p95Ms}`,
            `rag_retrieval_latency_ms{quantile="0.99"} ${metrics.retrieval.percentiles.p99Ms}`,
            `rag_retrieval_latency_ms_avg ${metrics.retrieval.avgLatencyMs}`,
            ``,
            `# HELP rag_db_pool_connections Active database connections`,
            `# TYPE rag_db_pool_connections gauge`,
            `rag_db_pool_connections{state="total"} ${metrics.database.poolTotalConnections}`,
            `rag_db_pool_connections{state="idle"} ${metrics.database.poolIdleConnections}`,
            `rag_db_pool_connections{state="waiting"} ${metrics.database.poolWaitingCount}`,
            ``,
            `# HELP rag_cache_hit_rate Graph cache hit rate`,
            `# TYPE rag_cache_hit_rate gauge`,
            `rag_cache_hits_total ${metrics.graphCache.hits}`,
            `rag_cache_misses_total ${metrics.graphCache.misses}`,
        ].join("\n");
    }
}
export const metricsCollector = new MetricsCollector();
//# sourceMappingURL=observability.js.map