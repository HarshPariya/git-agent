export interface PercentileMetrics {
    p50Ms: number;
    p90Ms: number;
    p95Ms: number;
    p99Ms: number;
}
export interface SlowQueryRecord {
    timestamp: string;
    query: string;
    repository: string;
    totalMs: number;
    vectorMs: number;
    graphMs: number;
    rerankMs: number;
}
export interface RepositoryMetricSummary {
    repository: string;
    totalRequests: number;
    failedRequests: number;
    avgLatencyMs: number;
}
export interface SystemMetrics {
    healthScore: {
        status: "EXCELLENT" | "GOOD" | "DEGRADED" | "CRITICAL";
        scorePercentage: number;
        description: string;
    };
    retrieval: {
        totalRequests: number;
        failedRequests: number;
        totalLatencyMs: number;
        avgLatencyMs: number;
        percentiles: PercentileMetrics;
        vectorLatencyMs: number;
        graphLatencyMs: number;
        rerankLatencyMs: number;
    };
    database: {
        totalQueries: number;
        failedQueries: number;
        poolTotalConnections: number;
        poolIdleConnections: number;
        poolWaitingCount: number;
    };
    embeddings: {
        modelLoadTimeMs: number;
        totalEmbeddings: number;
        failedEmbeddings: number;
        avgLatencyMs: number;
    };
    graphCache: {
        hits: number;
        misses: number;
        hitRate: string;
    };
    indexing: {
        totalIndexedFiles: number;
        totalDeletedFiles: number;
        lastIndexingDurationMs: number;
    };
    slowQueries: SlowQueryRecord[];
    perRepository: Record<string, RepositoryMetricSummary>;
}
declare class MetricsCollector {
    private retrievalRequests;
    private failedRetrievals;
    private totalRetrievalLatencyMs;
    private totalVectorLatencyMs;
    private totalGraphLatencyMs;
    private totalRerankLatencyMs;
    private latencySamples;
    private slowQueries;
    private repoMetricsMap;
    private dbQueries;
    private failedDbQueries;
    private cacheHits;
    private cacheMisses;
    private indexedFiles;
    private deletedFiles;
    private lastIndexingDurationMs;
    private readonly SLOW_QUERY_THRESHOLD_MS;
    recordRetrieval(totalMs: number, vectorMs: number, graphMs: number, rerankMs: number, success?: boolean, queryText?: string, repository?: string): void;
    recordDbQuery(success?: boolean): void;
    recordCacheHit(hit: boolean): void;
    recordRagMetrics(metrics: {
        retrievalMode: string;
        retrievedCandidates: number;
        rerankedCandidates: number;
        sentToLLM: number;
        ragContextTokens: number;
        memoryTokens: number;
        systemTokens: number;
        queryTokens: number;
        llmInputTokens: number;
        llmOutputTokens: number;
    }): void;
    recordIndexing(indexed: number, deleted: number, durationMs: number): void;
    private calculatePercentiles;
    calculateHealthScore(): SystemMetrics["healthScore"];
    getMetrics(embeddingStats?: {
        modelLoadTimeMs: number;
        totalEmbeddings: number;
        failedEmbeddings: number;
        averageLatencyMs: number;
    }): SystemMetrics;
    getPrometheusFormat(embeddingStats?: {
        modelLoadTimeMs: number;
        totalEmbeddings: number;
        failedEmbeddings: number;
        averageLatencyMs: number;
    }): string;
}
export declare const metricsCollector: MetricsCollector;
export {};
//# sourceMappingURL=observability.d.ts.map