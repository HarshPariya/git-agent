export type ToolOperationType = "read" | "write" | "delete";
export declare const sanitizeWorkspacePath: (baseDir: string, requestedPath: string, op?: ToolOperationType) => string;
export declare const resolveWorkspaceCandidate: (baseDir: string, requestedPath: string, op?: ToolOperationType) => Promise<string>;
//# sourceMappingURL=workspace-path.d.ts.map