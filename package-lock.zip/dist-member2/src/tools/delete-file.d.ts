import type { DeleteFileInput, DeleteFileOutput, ToolDefinition } from "../types/tools.js";
export declare const createDeleteFileTool: (baseDir?: string) => ToolDefinition<DeleteFileInput, DeleteFileOutput>;
//# sourceMappingURL=delete-file.d.ts.map