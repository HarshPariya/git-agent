import type { ReadFileInput, ReadFileOutput, ToolDefinition } from "../types/tools.js";
export declare const createReadFileTool: (baseDir?: string) => ToolDefinition<ReadFileInput, ReadFileOutput>;
//# sourceMappingURL=read-file.d.ts.map