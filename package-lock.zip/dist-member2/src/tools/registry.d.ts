import type { ToolDefinition, RuntimeTool, ToolExecutionContext, ToolExecutionResult } from "../types/tools.js";
export declare class ToolRegistry {
    private readonly tools;
    register<TInput, TOutput>(tool: ToolDefinition<TInput, TOutput>): void;
    get<TInput, TOutput>(name: string): ToolDefinition<TInput, TOutput>;
    getRuntime(name: string, context: ToolExecutionContext): RuntimeTool;
    list(context?: ToolExecutionContext): readonly RuntimeTool[];
    private hasPermission;
    private checkPermissions;
    executeTool<TOutput>(name: string, input: unknown, context: ToolExecutionContext): Promise<ToolExecutionResult<TOutput>>;
}
//# sourceMappingURL=registry.d.ts.map