import { logger } from "../logging/logger.js";
export class ToolRegistry {
    tools = new Map();
    register(tool) {
        this.tools.has(tool.name) &&
            (() => {
                throw new Error(`Tool already registered: ${tool.name}`);
            })();
        this.tools.set(tool.name, tool);
    }
    get(name) {
        const tool = this.tools.get(name) ??
            (() => {
                throw new Error(`Unknown tool: ${name}`);
            })();
        return tool;
    }
    getRuntime(name, context) {
        const tool = this.tools.get(name) ??
            (() => {
                throw new Error(`Unknown tool: ${name}`);
            })();
        this.checkPermissions(tool.permissions, context.userPermissions);
        return {
            name: tool.name,
            description: tool.description,
            parameters: tool.parameters,
            permissions: tool.permissions,
            timeoutMs: tool.timeoutMs,
            execute: async (input) => tool.execute({
                input: tool.parseInput(input),
                permissions: context.userPermissions,
            }),
        };
    }
    list(context) {
        const userPermissions = context?.userPermissions ?? [];
        return [...this.tools.values()]
            .filter((tool) => this.hasPermission(tool.permissions, userPermissions))
            .map((tool) => ({
            name: tool.name,
            description: tool.description,
            parameters: tool.parameters,
            permissions: tool.permissions,
            timeoutMs: tool.timeoutMs,
            execute: async (input) => tool.execute({
                input: tool.parseInput(input),
                permissions: userPermissions,
            }),
        }));
    }
    hasPermission(required, user) {
        return (required.length === 0 ||
            (user.length > 0 && required.every((p) => user.includes(p))));
    }
    checkPermissions(required, user) {
        !this.hasPermission(required, user) &&
            (() => {
                throw new Error(`Insufficient permissions for tool. Required: ${required.join(", ")}, User: ${user.join(", ")}`);
            })();
    }
    async executeTool(name, input, context) {
        const startTime = Date.now();
        const tool = this.tools.get(name);
        if (!tool) {
            const result = {
                toolName: name,
                callId: crypto.randomUUID(),
                success: false,
                output: undefined,
                error: `Unknown tool: ${name}`,
                durationMs: Date.now() - startTime,
            };
            logger.warn("Tool execution failed", {
                operation: "tool.execute",
                metadata: {
                    ...result,
                    tenantId: context.tenantId,
                    sessionId: context.sessionId,
                },
            });
            return result;
        }
        this.checkPermissions(tool.permissions, context.userPermissions);
        logger.info("Tool execution started", {
            operation: "tool.execute",
            metadata: {
                toolName: name,
                timeoutMs: tool.timeoutMs,
                tenantId: context.tenantId,
                sessionId: context.sessionId,
            },
        });
        let timer;
        try {
            const parsedInput = tool.parseInput(input);
            const timeoutMs = tool.timeoutMs ?? 30_000;
            const executePromise = tool.execute({
                input: parsedInput,
                permissions: context.userPermissions,
            });
            const timeoutPromise = new Promise((_, reject) => {
                timer = setTimeout(() => reject(new Error("Tool execution timeout")), timeoutMs);
            });
            const output = await Promise.race([executePromise, timeoutPromise]);
            const result = {
                toolName: name,
                callId: crypto.randomUUID(),
                success: true,
                output: output,
                error: undefined,
                durationMs: Date.now() - startTime,
            };
            logger.info("Tool execution completed", {
                operation: "tool.execute",
                metadata: {
                    toolName: name,
                    success: true,
                    durationMs: result.durationMs,
                    tenantId: context.tenantId,
                    sessionId: context.sessionId,
                },
            });
            return result;
        }
        catch (error) {
            const result = {
                toolName: name,
                callId: crypto.randomUUID(),
                success: false,
                output: undefined,
                error: error instanceof Error ? error.message : "Tool execution failed",
                durationMs: Date.now() - startTime,
            };
            logger.error("Tool execution failed", {
                operation: "tool.execute",
                metadata: {
                    toolName: name,
                    success: false,
                    error: result.error,
                    durationMs: result.durationMs,
                    tenantId: context.tenantId,
                    sessionId: context.sessionId,
                },
            });
            return result;
        }
        finally {
            timer && clearTimeout(timer);
        }
    }
}
//# sourceMappingURL=registry.js.map