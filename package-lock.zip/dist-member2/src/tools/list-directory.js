import fs from "node:fs/promises";
import path from "node:path";
const DEFAULT_PERMISSIONS = ["read"];
const DEFAULT_TIMEOUT_MS = 10_000;
const MAX_ALLOWED_ENTRIES = 200;
const BLOCKED_NAMES = new Set([
    ".git",
    "node_modules",
    ".env",
    ".env.local",
    "dist",
    "dist-member2",
    ".turbo",
    ".next",
]);
const parameters = {
    type: "object",
    properties: {
        path: {
            type: "string",
            description: "Relative directory path within the project (e.g. 'src/agent', 'src', '.'). Defaults to '.'",
        },
        recursive: {
            description: "Whether to list subdirectories recursively (max depth 2). Accepts true/false.",
        },
        maxEntries: {
            description: "Maximum number of entries to return (default 200).",
        },
    },
    additionalProperties: false,
};
const sanitizePath = (baseDir, requestedPath) => {
    const containsNull = requestedPath.includes("\0");
    containsNull && (() => { throw new Error("Path contains illegal null bytes"); })();
    const resolved = path.resolve(baseDir, requestedPath);
    const relative = path.relative(baseDir, resolved);
    const isEscaping = relative.startsWith("..") || path.isAbsolute(relative);
    isEscaping && (() => { throw new Error("Access denied: path escapes workspace root"); })();
    return resolved;
};
const parseInput = (input) => {
    const data = (typeof input === "object" && input !== null ? input : {});
    const requestedPath = typeof data.path === "string" && data.path.trim() ? data.path.trim() : ".";
    const recursive = data.recursive === true || String(data.recursive).toLowerCase() === "true";
    const rawMax = typeof data.maxEntries === "number" ? data.maxEntries : Number(data.maxEntries);
    const maxEntries = !isNaN(rawMax) && rawMax > 0 ? Math.min(rawMax, MAX_ALLOWED_ENTRIES) : MAX_ALLOWED_ENTRIES;
    return { path: requestedPath, recursive, maxEntries };
};
const scanDirectory = async (baseDir, targetDir, recursive, maxEntries, currentDepth = 0) => {
    const results = [];
    const entries = await fs.readdir(targetDir, { withFileTypes: true });
    for (const entry of entries) {
        if (results.length >= maxEntries)
            break;
        if (BLOCKED_NAMES.has(entry.name))
            continue;
        const fullPath = path.join(targetDir, entry.name);
        const relativePath = path.relative(baseDir, fullPath).replace(/\\/g, "/");
        if (entry.isDirectory()) {
            results.push({ name: entry.name, relativePath, type: "directory" });
            if (recursive && currentDepth < 2) {
                const nested = await scanDirectory(baseDir, fullPath, recursive, maxEntries - results.length, currentDepth + 1);
                results.push(...nested);
            }
        }
        else if (entry.isFile()) {
            results.push({ name: entry.name, relativePath, type: "file" });
        }
    }
    return results;
};
export const createListDirectoryTool = (baseDir = process.cwd()) => ({
    name: "list_directory",
    description: "Lists files and subdirectories within a project directory.",
    parameters,
    permissions: DEFAULT_PERMISSIONS,
    timeoutMs: DEFAULT_TIMEOUT_MS,
    parseInput,
    execute: async ({ input }) => {
        const targetDir = sanitizePath(baseDir, input.path ?? ".");
        const entries = await scanDirectory(baseDir, targetDir, input.recursive ?? false, input.maxEntries ?? MAX_ALLOWED_ENTRIES);
        return {
            path: input.path ?? ".",
            totalEntries: entries.length,
            entries,
        };
    },
});
//# sourceMappingURL=list-directory.js.map