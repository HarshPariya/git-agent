import type { ListDirectoryInput, ListDirectoryOutput, ToolDefinition } from "../types/tools.js";
export declare const createListDirectoryTool: (baseDir?: string) => ToolDefinition<ListDirectoryInput, ListDirectoryOutput>;
//# sourceMappingURL=list-directory.d.ts.map