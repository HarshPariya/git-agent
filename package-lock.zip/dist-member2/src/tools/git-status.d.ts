import type { GitStatusInput, GitStatusOutput, ToolDefinition } from "../types/tools.js";
export declare const createGitStatusTool: (baseDir?: string) => ToolDefinition<GitStatusInput, GitStatusOutput>;
//# sourceMappingURL=git-status.d.ts.map