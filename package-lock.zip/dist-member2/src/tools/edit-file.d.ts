import type { EditFileInput, EditFileOutput, ToolDefinition } from "../types/tools.js";
export declare const createEditFileTool: (baseDir?: string) => ToolDefinition<EditFileInput, EditFileOutput>;
//# sourceMappingURL=edit-file.d.ts.map