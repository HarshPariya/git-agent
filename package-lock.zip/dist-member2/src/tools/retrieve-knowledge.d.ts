import type { RetrievalRequest, RetrievalResult } from "../retrieval/types.js";
import type { ToolDefinition } from "../types/tools.js";
export type KnowledgeRetriever = (request: RetrievalRequest) => Promise<readonly RetrievalResult[]>;
export declare const createKnowledgeTool: (retriever: KnowledgeRetriever) => ToolDefinition<RetrievalRequest, readonly RetrievalResult[]>;
//# sourceMappingURL=retrieve-knowledge.d.ts.map