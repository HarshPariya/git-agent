import type { ToolDefinition, WriteFileInput, WriteFileOutput } from "../types/tools.js";
export declare const createWriteFileTool: (baseDir?: string) => ToolDefinition<WriteFileInput, WriteFileOutput>;
//# sourceMappingURL=write-file.d.ts.map