import type { HybridSearchResult } from "./hybrid-search.js";
export interface RerankOptions {
    limit?: number;
}
export interface RerankedResult extends HybridSearchResult {
    rerankScore: number;
    rerankSignals: {
        hybridBase: number;
        exactNameBonus: number;
        agreementBonus: number;
        depthBonus: number;
        typeBonus: number;
    };
}
export declare function rerankResults(query: string, results: HybridSearchResult[], options?: RerankOptions): RerankedResult[];
//# sourceMappingURL=reranker.d.ts.map