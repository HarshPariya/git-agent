import type { CodeGraph } from "../graph/graph-builder.js";
import type { GraphEntity, EntityType } from "../graph/entity-extractor.js";
import type { RelationshipType } from "../graph/relationship-extractor.js";
export interface GraphSearchOptions {
    limit?: number | undefined;
    maxDepth?: number | undefined;
    entityTypes?: EntityType[] | undefined;
    relationshipTypes?: RelationshipType[] | undefined;
}
export interface GraphSearchResult {
    entity: GraphEntity;
    score: number;
    matchType: "exact" | "name" | "partial" | "graph";
    depth: number;
    matchedTerm?: string | undefined;
}
export declare function graphSearch(graph: CodeGraph, query: string, options?: GraphSearchOptions): GraphSearchResult[];
//# sourceMappingURL=graph-search.d.ts.map