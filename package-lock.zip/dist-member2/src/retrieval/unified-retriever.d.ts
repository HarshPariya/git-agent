import type { RetrievalRequest, RetrievalResult, Retriever } from "./types.js";
import { CodeRetriever } from "./retriever.js";
export interface UnifiedRetrievalRequest extends RetrievalRequest {
    readonly tenantId: string;
    readonly documentIds?: readonly string[] | undefined;
    readonly mode?: "code" | "document" | "mixed" | "general" | "system" | undefined;
}
export interface UnifiedRetrievalResult extends RetrievalResult {
    readonly sourceType: "code" | "document";
    readonly documentId?: string | undefined;
    readonly pageNumber?: number | undefined;
}
export declare class UnifiedRetriever implements Retriever {
    private readonly codeRetriever;
    private readonly documentRetriever;
    constructor(codeRetriever: CodeRetriever);
    search(request: UnifiedRetrievalRequest): Promise<readonly UnifiedRetrievalResult[]>;
}
//# sourceMappingURL=unified-retriever.d.ts.map