import type { UnifiedRetrievalResult } from "./unified-retriever.js";
export interface CompressedEvidence {
    readonly id: string;
    readonly sourceType: "code" | "document";
    readonly source: string;
    readonly location?: string | undefined;
    readonly page?: number | undefined;
    readonly content: string;
    readonly score: number;
}
export interface CompressionResult {
    readonly evidence: readonly CompressedEvidence[];
    readonly candidatesRetrieved: number;
    readonly candidateCountAfterDeduplication: number;
    readonly sentToLLM: number;
}
export declare function compressContext(candidates: readonly UnifiedRetrievalResult[], maxEvidenceCount?: number, minScoreThreshold?: number): CompressionResult;
//# sourceMappingURL=context-compressor.d.ts.map