import { type VectorSearchFilterOptions } from "../db/vector-store.js";
export interface RetrieverOptions {
    limit?: number | undefined;
    vectorWeight?: number | undefined;
    graphWeight?: number | undefined;
    graphMaxDepth?: number | undefined;
    filterOptions?: VectorSearchFilterOptions | undefined;
}
export interface RetrievedContext {
    rank: number;
    name: string;
    type?: string | undefined;
    filePath?: string | undefined;
    startLine?: number | undefined;
    endLine?: number | undefined;
    content?: string | undefined;
    score: number;
    vectorScore: number;
    graphScore: number;
    rerankScore?: number | undefined;
    sources: Array<"vector" | "graph">;
}
export interface RetrieverStats {
    rootDirectory: string;
    files: number;
    chunks: number;
    graphNodes: number;
    graphEdges: number;
}
export declare function parseRequestedFilename(query: string): string | undefined;
export declare function parseRequestedSymbol(query: string): string | undefined;
export declare class CodeRetriever {
    private readonly rootDirectory;
    private readonly repositoryName;
    private chunks;
    private graph?;
    private initialized;
    private fileCount;
    constructor(rootDirectory: string, repositoryName?: string);
    initialize(): Promise<void>;
    retrieve(query: string, options?: RetrieverOptions): Promise<RetrievedContext[]>;
    search(request: {
        readonly query: string;
        readonly limit?: number;
    }): Promise<readonly {
        readonly content: string;
        readonly source: string;
        readonly score: number;
        readonly metadata?: Readonly<Record<string, string>>;
    }[]>;
    getStats(): RetrieverStats;
}
//# sourceMappingURL=retriever.d.ts.map