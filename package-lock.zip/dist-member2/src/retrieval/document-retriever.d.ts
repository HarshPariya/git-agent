export interface DocumentSearchRequest {
    readonly query: string;
    readonly tenantId: string;
    readonly documentIds?: readonly string[] | undefined;
    readonly limit?: number | undefined;
}
export interface DocumentSearchResult {
    readonly id: string;
    readonly documentId: string;
    readonly filename: string;
    readonly pageNumber?: number | undefined;
    readonly section?: string | undefined;
    readonly content: string;
    readonly score: number;
}
/** Pick a useful lexical probe instead of words such as "what" or "the". */
export declare function getDocumentSearchKeyword(searchQuery: string): string;
export declare function extractDocumentSearchTerms(searchQuery: string): string[];
export declare function isDocumentSummaryIntent(query: string): boolean;
export declare class DocumentRetriever {
    search({ query, tenantId, documentIds, limit, }: DocumentSearchRequest): Promise<readonly DocumentSearchResult[]>;
}
//# sourceMappingURL=document-retriever.d.ts.map