import type { RetrievalRequest, RetrievalResult, Retriever } from "./types.js";
export declare class MockRetriever implements Retriever {
    search(request: RetrievalRequest): Promise<readonly RetrievalResult[]>;
}
//# sourceMappingURL=mock-retriever.d.ts.map