import type { CodeGraph } from "../graph/graph-builder.js";
import type { CodeChunk } from "../ingestion/chunker.js";
import type { VectorSearchResult } from "./vector-search.js";
export interface HybridSearchOptions {
    limit?: number | undefined;
    graphLimit?: number | undefined;
    graphMaxDepth?: number | undefined;
    vectorWeight?: number | undefined;
    graphWeight?: number | undefined;
}
export interface HybridSearchResult {
    chunk?: CodeChunk | undefined;
    name: string;
    filePath?: string | undefined;
    vectorScore: number;
    graphScore: number;
    hybridScore: number;
    sources: Array<"vector" | "graph">;
    graphDepth?: number | undefined;
    graphMatchType?: string | undefined;
}
export declare function hybridSearch(query: string, graph: CodeGraph, chunks: CodeChunk[], vectorResults: VectorSearchResult[], options?: HybridSearchOptions): Promise<HybridSearchResult[]>;
//# sourceMappingURL=hybrid-search.d.ts.map