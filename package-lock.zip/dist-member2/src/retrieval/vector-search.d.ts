import type { CodeChunk } from "../ingestion/chunker.js";
export interface VectorDocument {
    chunk: CodeChunk;
    embedding: number[];
}
export interface VectorSearchResult {
    chunk: CodeChunk;
    score: number;
}
export declare function buildVectorIndex(chunks: CodeChunk[]): Promise<VectorDocument[]>;
export declare function vectorSearch(query: string, index: VectorDocument[], limit?: number): Promise<VectorSearchResult[]>;
//# sourceMappingURL=vector-search.d.ts.map