import type { EvaluationMetrics, EvaluationObservation } from "../types/evaluation.js";
export type { EvaluationMetrics, EvaluationObservation };
export declare const calculateMetrics: (observations: readonly EvaluationObservation[]) => EvaluationMetrics;
//# sourceMappingURL=metrics.d.ts.map