import type { AgentExecutionResult } from "../types/agent.js";
import type { EvaluationCase, EvaluationReport, EvaluationResult } from "../types/evaluation.js";
export type { EvaluationReport, EvaluationResult };
export declare const evaluateDataset: (cases: readonly EvaluationCase[], run: (evaluationCase: EvaluationCase) => Promise<AgentExecutionResult>) => Promise<EvaluationReport>;
//# sourceMappingURL=evaluator.d.ts.map