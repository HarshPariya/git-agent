import type { EvaluationCase } from "../types/evaluation.js";
export type { EvaluationCase };
export declare const evaluationDataset: readonly EvaluationCase[];
//# sourceMappingURL=dataset.d.ts.map