import type { InputGuardRequest, InputGuardResult } from "../types/guardrails.js";
export type { InputGuardRequest, InputGuardResult };
export declare const validateInput: ({ message, }: InputGuardRequest) => InputGuardResult;
//# sourceMappingURL=input-guard.d.ts.map