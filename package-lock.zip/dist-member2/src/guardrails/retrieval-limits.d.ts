export declare class ResourceLimitError extends Error {
    constructor(message: string);
}
export declare function validateQueryLength(query: string): string;
export declare function validateTopK(limit?: number): number;
export declare function validateChunkContentSize(content: string): string;
export declare function validateRepositoryScan(fileCount: number, totalSizeBytes: number): void;
export declare function validateRepositoryChunkCount(totalChunks: number): void;
export declare function validateGraphDepth(depth?: number): number;
//# sourceMappingURL=retrieval-limits.d.ts.map