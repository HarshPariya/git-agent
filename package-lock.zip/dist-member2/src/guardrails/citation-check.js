const CITATION_PATTERN = /\[([^\]]+)\]/g;
export const extractCitations = (answer) => [...answer.matchAll(CITATION_PATTERN)]
    .map((match) => match[1]?.trim())
    .filter((citation) => Boolean(citation));
const normalize = (value) => value.trim().toLowerCase();
const matchesSource = (citation, source) => {
    const normCitation = normalize(citation);
    const normSource = normalize(source.source);
    return (normCitation === normSource ||
        normCitation === `${normSource} page ${source.page}`);
};
export const verifyCitations = ({ answer, sources, }) => {
    const citations = extractCitations(answer);
    const invalidCitation = citations.find((citation) => !sources.some((source) => matchesSource(citation, source)));
    return citations.length === 0
        ? {
            valid: false,
            citations,
            reason: "No citations were found in the answer.",
        }
        : invalidCitation
            ? {
                valid: false,
                citations,
                reason: `Citation does not match retrieved sources: ${invalidCitation}`,
            }
            : {
                valid: true,
                citations,
                reason: "All citations match retrieved sources.",
            };
};
//# sourceMappingURL=citation-check.js.map