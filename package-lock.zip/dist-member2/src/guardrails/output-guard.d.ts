import type { OutputGuardRequest, OutputGuardResult } from "../types/guardrails.js";
export type { OutputGuardRequest, OutputGuardResult };
export declare const validateOutput: ({ response, }: OutputGuardRequest) => OutputGuardResult;
//# sourceMappingURL=output-guard.d.ts.map