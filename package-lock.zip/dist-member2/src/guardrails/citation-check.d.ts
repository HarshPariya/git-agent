import type { CitationCheckRequest, CitationCheckResult } from "../types/guardrails.js";
export type { CitationCheckRequest, CitationCheckResult };
export declare const extractCitations: (answer: string) => readonly string[];
export declare const verifyCitations: ({ answer, sources, }: CitationCheckRequest) => CitationCheckResult;
//# sourceMappingURL=citation-check.d.ts.map