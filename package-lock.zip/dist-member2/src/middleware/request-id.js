import { randomUUID } from "node:crypto";
export const requestIdMiddleware = (request, response, next) => {
    const requestId = request.header("x-request-id")?.trim() || randomUUID();
    response.setHeader("x-request-id", requestId);
    Object.defineProperty(request, "requestId", {
        value: requestId,
        enumerable: false,
        writable: false,
    });
    next();
};
//# sourceMappingURL=request-id.js.map