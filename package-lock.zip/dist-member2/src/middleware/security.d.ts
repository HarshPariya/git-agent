import type { NextFunction, Request, Response } from "express";
export declare const securityMiddleware: (request: Request, response: Response, next: NextFunction) => void;
//# sourceMappingURL=security.d.ts.map