import type { RequestHandler } from "express";
export declare const requestIdMiddleware: RequestHandler;
//# sourceMappingURL=request-id.d.ts.map