import type { CostMetrics, LlmCostConfig, TokenUsage } from "../types/llm.js";
export type { CostMetrics, LlmCostConfig, TokenUsage };
export declare class LlmCostOptimizer {
    private readonly config;
    private readonly cache;
    private readonly metrics;
    private readonly tokenCounts;
    private readonly minuteWindow;
    constructor(config?: Partial<LlmCostConfig>);
    private estimateTokens;
    private generateCacheKey;
    checkRateLimit(): {
        allowed: boolean;
        retryAfterMs?: number;
    };
    getCachedResponse(instructions: string, input: string): {
        text: string;
        tokens: TokenUsage;
    } | null;
    cacheResponse(instructions: string, input: string, response: string, tokens: TokenUsage): void;
    recordUsage(tokens: TokenUsage): void;
    getMetrics(): CostMetrics;
    truncateContext(context: string, maxTokens: number): string;
    summarizeIfNeeded(context: string): string;
    resetMetrics(): void;
}
export declare const createLlmCostOptimizer: (config?: Partial<LlmCostConfig>) => LlmCostOptimizer;
//# sourceMappingURL=cost-optimizer.d.ts.map