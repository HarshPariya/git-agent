export const mockProvider = {
    async generate({ input }) {
        return {
            id: "mock-response",
            model: "mock",
            text: `Mock response for: ${input}`,
        };
    },
};
//# sourceMappingURL=mock-client.js.map