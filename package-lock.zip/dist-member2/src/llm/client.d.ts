import Groq from "groq-sdk";
import type { LlmProvider, LlmRequest, LlmResponse, LlmTool, ToolLlmResponse } from "../types/llm.js";
export type { LlmTool, ToolLlmResponse };
export declare const generateText: ({ instructions, input, }: LlmRequest) => Promise<LlmResponse>;
export declare const groqProvider: LlmProvider;
export declare const generateWithTools: ({ instructions, input, tools, }: {
    readonly instructions: string;
    readonly input: string;
    readonly tools: readonly LlmTool[];
}) => Promise<ToolLlmResponse>;
export declare const continueWithTools: ({ instructions, messages, tools, }: {
    readonly instructions: string;
    readonly messages: readonly Groq.Chat.Completions.ChatCompletionMessageParam[];
    readonly tools: readonly LlmTool[];
}) => Promise<ToolLlmResponse>;
//# sourceMappingURL=client.d.ts.map