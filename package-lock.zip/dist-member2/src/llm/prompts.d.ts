export interface PromptContext {
    readonly question: string;
    readonly retrievedContext?: string;
    readonly conversationContext?: string;
}
export declare const buildSystemPrompt: (mode?: string) => string;
export declare const buildUserPrompt: ({ question, retrievedContext, conversationContext, }: PromptContext) => string;
//# sourceMappingURL=prompts.d.ts.map