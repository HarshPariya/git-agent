import type { LlmProvider } from "../types/llm.js";
export declare const mockProvider: LlmProvider;
//# sourceMappingURL=mock-client.d.ts.map