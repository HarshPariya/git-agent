import { continueWithTools, generateText, generateWithTools, } from "./client.js";
export const generateWithLlm = (request) => generateText(request);
export const generateLlmWithTools = ({ instructions, input, tools, }) => generateWithTools({
    instructions,
    input,
    tools,
});
export const continueLlmWithTools = ({ instructions, messages, tools, }) => continueWithTools({
    instructions,
    messages,
    tools,
});
//# sourceMappingURL=router.js.map