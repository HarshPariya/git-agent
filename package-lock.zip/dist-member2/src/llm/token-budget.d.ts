import type { CompressedEvidence } from "../retrieval/context-compressor.js";
export interface TokenBudgetConfig {
    readonly maxRagContextTokens: number;
    readonly maxMemoryTokens: number;
    readonly maxSourceMetadataTokens: number;
    readonly maxRetrievedChunks: number;
}
export interface BudgetedContextResult {
    readonly formattedEvidence: string;
    readonly evidenceItems: readonly CompressedEvidence[];
    readonly ragContextTokens: number;
    readonly droppedChunkCount: number;
}
export declare function estimateTokens(text: string): number;
export declare class TokenBudgetManager {
    private readonly config;
    constructor(customConfig?: Partial<TokenBudgetConfig>);
    fitEvidence(evidence: readonly CompressedEvidence[]): BudgetedContextResult;
    fitMemory(memoryText: string): {
        formattedMemory: string;
        memoryTokens: number;
    };
}
//# sourceMappingURL=token-budget.d.ts.map