import { env } from "../config/env.js";
export const healthHandler = (_request, response) => {
    response.status(200).json({
        status: "ok",
        environment: env.nodeEnv,
        modules: {
            retrieval: "ready",
            agent: "ready",
        },
        database: {
            poolIdleConnections: 0,
        },
    });
};
//# sourceMappingURL=health.js.map