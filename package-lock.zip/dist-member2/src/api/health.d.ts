import type { Request, Response } from "express";
export declare const healthHandler: (_request: Request, response: Response) => void;
//# sourceMappingURL=health.d.ts.map