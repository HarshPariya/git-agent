import type { Request, Response, NextFunction } from "express";
export declare function uploadDocumentHandler(req: Request, res: Response, next: NextFunction): Promise<void>;
export declare function listDocumentsHandler(req: Request, res: Response, next: NextFunction): Promise<void>;
export declare function deleteDocumentHandler(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=documents.d.ts.map