import type { NextFunction, Request, Response } from "express";
export declare function chatHandler(request: Request, response: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=chat.d.ts.map