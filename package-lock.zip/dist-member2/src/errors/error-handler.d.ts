import type { NextFunction, Request, Response } from "express";
export declare const errorHandler: (error: unknown, request: Request, response: Response, _next: NextFunction) => void;
//# sourceMappingURL=error-handler.d.ts.map