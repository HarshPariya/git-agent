import { logger } from "../logging/logger.js";
import { AppError } from "./app-error.js";
const getLogContext = (request, metadata) => ({
    ...(request.requestId !== undefined && { requestId: request.requestId }),
    operation: request.path,
    metadata,
});
export const errorHandler = (error, request, response, _next) => {
    const isAppError = error instanceof AppError;
    const status = isAppError ? error.statusCode : 500;
    const code = isAppError ? error.code : "INTERNAL_ERROR";
    const message = isAppError
        ? error.message
        : "An unexpected error occurred.";
    const logMessage = isAppError
        ? "Application error"
        : "Unhandled application error";
    const logDetails = isAppError
        ? { code, statusCode: status }
        : { error: error instanceof Error ? error.message : "Unknown error" };
    isAppError
        ? logger.warn(logMessage, getLogContext(request, logDetails))
        : logger.error(logMessage, getLogContext(request, logDetails));
    response.status(status).json({
        error: { code, message },
    });
};
//# sourceMappingURL=error-handler.js.map