export class AppError extends Error {
    code;
    statusCode;
    constructor(message, code, statusCode, options) {
        super(message, options);
        this.code = code;
        this.statusCode = statusCode;
        this.name = "AppError";
    }
}
//# sourceMappingURL=app-error.js.map