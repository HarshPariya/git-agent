export type ErrorCode = "VALIDATION_ERROR" | "AUTHENTICATION_ERROR" | "AUTHORIZATION_ERROR" | "NOT_FOUND" | "TOOL_ERROR" | "LLM_ERROR" | "EXTRACTION_FAILED" | "PERSISTENCE_UNAVAILABLE" | "INTERNAL_ERROR";
export declare class AppError extends Error {
    readonly code: ErrorCode;
    readonly statusCode: number;
    constructor(message: string, code: ErrorCode, statusCode: number, options?: ErrorOptions);
}
//# sourceMappingURL=app-error.d.ts.map