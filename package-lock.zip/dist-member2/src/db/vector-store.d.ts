import type { CodeChunk } from "../ingestion/chunker.js";
import type { VectorSearchResult } from "../retrieval/vector-search.js";
export interface StoredChunkRow {
    id: string;
    repository: string;
    file_path: string;
    chunk_type: string;
    name: string | null;
    language: string | null;
    start_line: number;
    end_line: number;
    content: string;
    metadata: Record<string, unknown>;
    content_hash?: string;
    similarity?: number;
}
export interface VectorSearchFilterOptions {
    repository?: string | undefined;
    language?: string | undefined;
    chunkType?: string | undefined;
    filePathPrefix?: string | undefined;
    metadata?: Record<string, unknown> | undefined;
    limit?: number | undefined;
}
export interface UpsertResultStats {
    inserted: number;
    updated: number;
    skipped: number;
    deletedStale: number;
    total: number;
}
export declare function deleteStaleChunks(repository: string, activeChunkIds: string[]): Promise<number>;
export declare function updateRepositoryStatus(repository: string, repoHash: string, totalFiles: number, totalChunks: number): Promise<void>;
export declare function upsertChunks(repository: string, chunks: CodeChunk[], repositoryHash?: string, totalFiles?: number): Promise<UpsertResultStats>;
export declare function pgVectorSearch(queryText: string, filterOrRepo?: string | VectorSearchFilterOptions, limitParam?: number): Promise<VectorSearchResult[]>;
//# sourceMappingURL=vector-store.d.ts.map