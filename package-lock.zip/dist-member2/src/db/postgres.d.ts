import "dotenv/config";
import { Pool, type PoolClient, type QueryResult, type QueryResultRow } from "pg";
export declare const pool: Pool;
export declare function query<T extends QueryResultRow = QueryResultRow>(text: string, params?: unknown[]): Promise<QueryResult<T>>;
export declare function queryWithRetry<T extends QueryResultRow = QueryResultRow>(text: string, params?: unknown[], maxRetries?: number, delayMs?: number): Promise<QueryResult<T>>;
export declare function withTransaction<T>(callback: (client: PoolClient) => Promise<T>): Promise<T>;
export interface DatabaseHealthStatus {
    status: "healthy" | "unhealthy";
    latencyMs: number;
    totalConnections: number;
    idleConnections: number;
    waitingCount: number;
    timestamp: string;
}
export declare function getDatabaseHealth(): Promise<DatabaseHealthStatus>;
export declare function testDatabaseConnection(): Promise<boolean>;
export declare function closeDatabase(): Promise<void>;
//# sourceMappingURL=postgres.d.ts.map