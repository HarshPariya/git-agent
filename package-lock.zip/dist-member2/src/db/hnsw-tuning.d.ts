export interface HnswTuningOptions {
    efSearch?: number;
    m?: number;
    efConstruction?: number;
}
export declare function setHnswSearchPrecision(efSearch?: number): Promise<void>;
export declare function rebuildHnswIndex(options?: HnswTuningOptions): Promise<void>;
//# sourceMappingURL=hnsw-tuning.d.ts.map