import crypto from "node:crypto";
import { embedText } from "../ingestion/embedder.js";
import { query } from "./postgres.js";
function computeContentHash(content) {
    return crypto.createHash("sha256").update(content).digest("hex");
}
export async function deleteStaleChunks(repository, activeChunkIds) {
    if (activeChunkIds.length === 0) {
        const result = await query(`DELETE FROM code_chunks WHERE repository = $1`, [repository]);
        return result.rowCount ?? 0;
    }
    const result = await query(`DELETE FROM code_chunks WHERE repository = $1 AND NOT (id = ANY($2::text[]))`, [repository, activeChunkIds]);
    const deletedCount = result.rowCount ?? 0;
    if (deletedCount > 0) {
        console.log(`🧹 Cleaned up ${deletedCount} stale code chunks from PostgreSQL.`);
    }
    return deletedCount;
}
export async function updateRepositoryStatus(repository, repoHash, totalFiles, totalChunks) {
    await query(`
    INSERT INTO repository_status (
      repository,
      repository_hash,
      total_files,
      total_chunks,
      status,
      last_indexed_at
    )
    VALUES ($1, $2, $3, $4, 'completed', NOW())
    ON CONFLICT (repository) DO UPDATE SET
      repository_hash = EXCLUDED.repository_hash,
      total_files = EXCLUDED.total_files,
      total_chunks = EXCLUDED.total_chunks,
      status = 'completed',
      last_indexed_at = NOW()
    `, [repository, repoHash, totalFiles, totalChunks]);
}
export async function upsertChunks(repository, chunks, repositoryHash = "", totalFiles = 0) {
    console.log(`💾 Processing ${chunks.length} chunks for PostgreSQL + pgvector...`);
    // 1. Clean up stale chunks no longer present in repository
    const activeChunkIds = chunks.map((c) => c.id);
    const deletedStale = await deleteStaleChunks(repository, activeChunkIds);
    // 2. Fetch existing hashes to skip unchanged chunks
    const existingRows = await query(`SELECT id, content_hash FROM code_chunks WHERE repository = $1`, [repository]);
    const existingHashMap = new Map();
    for (const row of existingRows.rows) {
        if (row.content_hash) {
            existingHashMap.set(row.id, row.content_hash);
        }
    }
    let inserted = 0;
    let updated = 0;
    let skipped = 0;
    for (const chunk of chunks) {
        if (!chunk.content.trim()) {
            continue;
        }
        const currentHash = computeContentHash(chunk.content);
        const storedHash = existingHashMap.get(chunk.id);
        // Skip embedding generation if content hash matches
        if (storedHash === currentHash) {
            skipped++;
            continue;
        }
        const embedding = await embedText([
            `Type: ${chunk.type}`,
            `Name: ${chunk.name ?? ""}`,
            `File: ${chunk.filePath}`,
            "",
            chunk.content,
        ].join("\n"));
        const vectorString = `[${embedding.join(",")}]`;
        await query(`
      INSERT INTO code_chunks (
        id,
        repository,
        file_path,
        chunk_type,
        name,
        language,
        start_line,
        end_line,
        content,
        metadata,
        embedding,
        content_hash,
        updated_at
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11::vector, $12, NOW())
      ON CONFLICT (id) DO UPDATE SET
        repository = EXCLUDED.repository,
        file_path = EXCLUDED.file_path,
        chunk_type = EXCLUDED.chunk_type,
        name = EXCLUDED.name,
        language = EXCLUDED.language,
        start_line = EXCLUDED.start_line,
        end_line = EXCLUDED.end_line,
        content = EXCLUDED.content,
        metadata = EXCLUDED.metadata,
        embedding = EXCLUDED.embedding,
        content_hash = EXCLUDED.content_hash,
        updated_at = NOW()
      `, [
            chunk.id,
            repository,
            chunk.filePath,
            chunk.type,
            chunk.name ?? null,
            chunk.language,
            chunk.startLine,
            chunk.endLine,
            chunk.content,
            JSON.stringify(chunk.metadata),
            vectorString,
            currentHash,
        ]);
        if (storedHash !== undefined) {
            updated++;
        }
        else {
            inserted++;
        }
    }
    // 3. Update indexing status record
    await updateRepositoryStatus(repository, repositoryHash, totalFiles, chunks.length);
    console.log(`✓ Incremental indexing finished: ${inserted} inserted, ${updated} updated, ${skipped} skipped, ${deletedStale} stale deleted (total ${chunks.length}).`);
    return { inserted, updated, skipped, deletedStale, total: chunks.length };
}
export async function pgVectorSearch(queryText, filterOrRepo, limitParam = 10) {
    const options = typeof filterOrRepo === "string"
        ? { repository: filterOrRepo, limit: limitParam }
        : filterOrRepo ?? { limit: limitParam };
    if (!options.repository) {
        throw new Error("Security Error: Repository scope is required for vector search.");
    }
    const queryEmbedding = await embedText(queryText);
    const vectorString = `[${queryEmbedding.join(",")}]`;
    const limit = options.limit ?? 10;
    let sql = `
    SELECT
      id,
      file_path,
      chunk_type,
      name,
      language,
      start_line,
      end_line,
      content,
      metadata,
      1 - (embedding <=> $1::vector) AS similarity
    FROM code_chunks
  `;
    const whereConditions = [];
    const params = [vectorString];
    // Mandated Repository Isolation
    params.push(options.repository);
    whereConditions.push(`repository = $${params.length}`);
    if (options.language) {
        params.push(options.language);
        whereConditions.push(`language = $${params.length}`);
    }
    if (options.chunkType) {
        params.push(options.chunkType);
        whereConditions.push(`chunk_type = $${params.length}`);
    }
    if (options.filePathPrefix) {
        params.push(`${options.filePathPrefix}%`);
        whereConditions.push(`file_path LIKE $${params.length}`);
    }
    if (options.metadata && Object.keys(options.metadata).length > 0) {
        params.push(JSON.stringify(options.metadata));
        whereConditions.push(`metadata @> $${params.length}::jsonb`);
    }
    if (whereConditions.length > 0) {
        sql += ` WHERE ` + whereConditions.join(" AND ");
    }
    params.push(limit);
    sql += `
    ORDER BY embedding <=> $1::vector ASC
    LIMIT $${params.length}
  `;
    const result = await query(sql, params);
    return result.rows.map((row) => ({
        chunk: {
            id: row.id,
            type: row.chunk_type,
            filePath: row.file_path,
            language: row.language,
            name: row.name ?? undefined,
            startLine: row.start_line,
            endLine: row.end_line,
            content: row.content,
            metadata: row.metadata,
        },
        score: Number(row.similarity ?? 0),
    }));
}
//# sourceMappingURL=vector-store.js.map