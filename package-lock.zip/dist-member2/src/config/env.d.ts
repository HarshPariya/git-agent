import "dotenv/config";
export declare const env: Readonly<{
    readonly nodeEnv: string;
    port: number;
    groqApiKey: string;
    groqModel: string;
    maxRagContextTokens: number;
    maxMemoryTokens: number;
    maxRetrievedChunks: number;
    ragDebugContext: boolean;
}>;
//# sourceMappingURL=env.d.ts.map