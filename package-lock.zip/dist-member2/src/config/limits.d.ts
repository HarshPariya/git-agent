import "dotenv/config";
export declare const LIMITS: {
    readonly maxQueryLength: number;
    readonly maxResults: number;
    readonly defaultResults: number;
    readonly maxFileSizeBytes: number;
    readonly maxChunkSizeBytes: number;
    readonly maxRepositoryFiles: number;
    readonly maxRepositorySizeBytes: number;
    readonly maxRepositoryChunks: number;
    readonly maxGraphDepth: number;
    readonly maxGraphNodesVisited: number;
};
//# sourceMappingURL=limits.d.ts.map