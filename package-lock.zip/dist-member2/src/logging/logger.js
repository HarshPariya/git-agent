const log = (level, message, context = {}) => {
    const entry = {
        timestamp: new Date().toISOString(),
        level,
        message,
        ...context,
    };
    process.stdout.write(`${JSON.stringify(entry)}\n`);
};
export const logger = Object.freeze({
    info: (message, context) => log("info", message, context),
    warn: (message, context) => log("warn", message, context),
    error: (message, context) => log("error", message, context),
});
//# sourceMappingURL=logger.js.map