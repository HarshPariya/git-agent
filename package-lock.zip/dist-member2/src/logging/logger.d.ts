import type { LogContext, LogLevel, StructuredLogger } from "../types/logging.js";
export type { LogContext, LogLevel, StructuredLogger };
export declare const logger: Readonly<{
    info: (message: string, context?: LogContext) => void;
    warn: (message: string, context?: LogContext) => void;
    error: (message: string, context?: LogContext) => void;
}>;
//# sourceMappingURL=logger.d.ts.map