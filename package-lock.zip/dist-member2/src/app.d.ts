export declare const app: import("express-serve-static-core").Express;
export declare const startServer: () => void;
//# sourceMappingURL=app.d.ts.map