import type { ParsedDocumentResult } from "./document-parser.js";
export interface DocumentChunk {
    readonly id: string;
    readonly documentId: string;
    readonly tenantId: string;
    readonly filename: string;
    readonly pageNumber?: number | undefined;
    readonly section?: string | undefined;
    readonly chunkIndex: number;
    readonly content: string;
    readonly contentHash: string;
}
export declare function chunkDocument(parsed: ParsedDocumentResult): readonly DocumentChunk[];
//# sourceMappingURL=document-chunker.d.ts.map