export type SupportedLanguage = "typescript" | "javascript" | "python" | "json" | "unknown";
export interface ParsedImport {
    source: string;
    names: string[];
    line: number;
}
export interface ParsedFunction {
    name: string;
    startLine: number;
    endLine: number;
    content: string;
}
export interface ParsedClass {
    name: string;
    startLine: number;
    endLine: number;
    content: string;
}
export interface ParsedFile {
    filePath: string;
    language: SupportedLanguage;
    content: string;
    imports: ParsedImport[];
    functions: ParsedFunction[];
    classes: ParsedClass[];
}
export declare function detectLanguage(filePath: string): SupportedLanguage;
export declare function extractJavaScriptFunctions(lines: string[]): ParsedFunction[];
export declare function extractJavaScriptClasses(lines: string[]): ParsedClass[];
export declare function parseFile(filePath: string): Promise<ParsedFile>;
export declare function scanRepository(rootDirectory: string): Promise<string[]>;
export declare function parseRepository(rootDirectory: string): Promise<ParsedFile[]>;
//# sourceMappingURL=parser.d.ts.map