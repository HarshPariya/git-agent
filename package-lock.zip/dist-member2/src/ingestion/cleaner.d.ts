export declare const MAX_FILE_SIZE_BYTES: number;
export declare const SECRET_PATTERNS: RegExp[];
export declare const IGNORED_DIRECTORIES: Set<string>;
export declare const IGNORED_FILES: Set<string>;
export declare function isPathWithinRoot(filePath: string, rootDirectory: string): boolean;
export declare function isSecretFile(filename: string): boolean;
export declare function isIgnoredDirectory(dirName: string): boolean;
export declare function isIgnoredFile(filename: string): boolean;
//# sourceMappingURL=cleaner.d.ts.map