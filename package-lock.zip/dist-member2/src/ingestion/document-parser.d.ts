export interface DocumentSourceMetadata {
    readonly documentId: string;
    readonly filename: string;
    readonly mimeType: string;
    readonly tenantId: string;
    readonly userId: string;
    readonly parserVersion?: string | undefined;
}
export interface ParsedDocumentSection {
    readonly pageNumber?: number | undefined;
    readonly section?: string | undefined;
    readonly content: string;
}
export interface TextQualityMetrics {
    readonly filename: string;
    readonly pageCount: number;
    readonly rawExtractedCharacters: number;
    readonly printableCharacterRatio: number;
    readonly alphabeticCharacterRatio: number;
    readonly replacementCharacterCount: number;
    readonly averageWordLength: number;
    readonly detectedTextQuality: "good" | "poor" | "unusable";
    readonly score: number;
}
export interface ParsedDocumentResult {
    readonly metadata: DocumentSourceMetadata;
    readonly sections: readonly ParsedDocumentSection[];
    readonly qualityMetrics?: TextQualityMetrics | undefined;
}
export declare function validateDocumentFile(filename: string, sizeBytes: number): void;
export declare function evaluateTextQuality(text: string, filename: string, pageCount?: number): TextQualityMetrics;
export declare function normalizeExtractedText(text: string): string;
export declare function parseDocumentContent(buffer: Buffer, filename: string, metadata: DocumentSourceMetadata): Promise<ParsedDocumentResult>;
//# sourceMappingURL=document-parser.d.ts.map