import type { DocumentChunk } from "./document-chunker.js";
import type { DocumentSourceMetadata } from "./document-parser.js";
export interface InMemDocument {
    readonly id: string;
    readonly tenantId: string;
    readonly userId: string;
    readonly filename: string;
    readonly mimeType: string;
    readonly sizeBytes: number;
    readonly status: string;
    readonly createdAt: Date;
    readonly chunks: readonly DocumentChunk[];
}
export declare const inMemoryDocumentStore: InMemDocument[];
export declare function indexDocument(metadata: DocumentSourceMetadata, sizeBytes: number, chunks: readonly DocumentChunk[]): Promise<{
    insertedChunks: number;
    storage: "postgres" | "memory";
}>;
export declare function deleteDocument(documentId: string, tenantId: string): Promise<boolean>;
//# sourceMappingURL=document-indexer.d.ts.map