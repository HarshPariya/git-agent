import type { ParsedFile, SupportedLanguage } from "./parser.js";
export type ChunkType = "file" | "function" | "class";
export interface CodeChunk {
    id: string;
    type: ChunkType;
    filePath: string;
    language: SupportedLanguage;
    name?: string | undefined;
    startLine: number;
    endLine: number;
    content: string;
    metadata: {
        fileName: string;
        directory: string;
        imports: string[];
    };
}
export declare function chunkFile(file: ParsedFile): CodeChunk[];
export declare function chunkRepository(parsedFiles: ParsedFile[]): CodeChunk[];
//# sourceMappingURL=chunker.d.ts.map