const DIMENSIONS = 384;
const metrics = {
    modelLoadTimeMs: 0,
    totalEmbeddings: 0,
    failedEmbeddings: 0,
    totalEmbeddingTimeMs: 0,
};
function hashFeature(feature) {
    let hash = 2166136261;
    for (let index = 0; index < feature.length; index++) {
        hash ^= feature.charCodeAt(index);
        hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
}
function createEmbedding(text) {
    const vector = new Array(DIMENSIONS).fill(0);
    const normalized = text.toLowerCase().replace(/[^a-z0-9_$.-]+/g, " ").trim();
    const words = normalized.split(/\s+/).filter(Boolean);
    const features = [
        ...words.map((word) => `word:${word}`),
        ...words.slice(0, -1).map((word, index) => `pair:${word}_${words[index + 1]}`),
    ];
    for (const word of words) {
        if (word.length < 3)
            continue;
        for (let index = 0; index <= word.length - 3; index++) {
            features.push(`tri:${word.slice(index, index + 3)}`);
        }
    }
    for (const feature of features) {
        const hash = hashFeature(feature);
        const bucket = hash % DIMENSIONS;
        vector[bucket] = (vector[bucket] ?? 0) + ((hash & 0x80000000) === 0 ? 1 : -1);
    }
    const magnitude = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0));
    if (magnitude === 0)
        return vector;
    return vector.map((value) => value / magnitude);
}
/** Compatibility hook for callers that previously loaded a transformer pipeline. */
export async function getExtractor() {
    return createEmbedding;
}
export async function embedText(text, _options = {}) {
    const startTime = Date.now();
    try {
        const embedding = createEmbedding(text);
        metrics.totalEmbeddings++;
        metrics.totalEmbeddingTimeMs += Date.now() - startTime;
        return embedding;
    }
    catch (error) {
        metrics.failedEmbeddings++;
        throw error;
    }
}
export async function embedChunks(chunks, options) {
    return Promise.all(chunks.map(async (chunk) => ({
        id: chunk.id,
        embedding: await embedText(chunk.content, options),
    })));
}
export function getEmbeddingMetrics() {
    return {
        modelLoadTimeMs: metrics.modelLoadTimeMs,
        totalEmbeddings: metrics.totalEmbeddings,
        failedEmbeddings: metrics.failedEmbeddings,
        averageLatencyMs: metrics.totalEmbeddings > 0
            ? Math.round(metrics.totalEmbeddingTimeMs / metrics.totalEmbeddings)
            : 0,
    };
}
//# sourceMappingURL=embedder.js.map