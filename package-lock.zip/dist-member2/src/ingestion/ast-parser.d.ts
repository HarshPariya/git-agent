import type { ParsedImport, ParsedFunction, ParsedClass } from "./parser.js";
export interface ASTParseResult {
    imports: ParsedImport[];
    functions: ParsedFunction[];
    classes: ParsedClass[];
}
export declare function parseTypeScriptAST(content: string, filePath: string): ASTParseResult;
//# sourceMappingURL=ast-parser.d.ts.map