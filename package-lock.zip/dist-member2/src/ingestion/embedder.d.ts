export interface EmbeddingMetrics {
    modelLoadTimeMs: number;
    totalEmbeddings: number;
    failedEmbeddings: number;
    totalEmbeddingTimeMs: number;
}
/** Compatibility hook for callers that previously loaded a transformer pipeline. */
export declare function getExtractor(): Promise<(text: string) => number[]>;
export interface EmbedOptions {
    maxRetries?: number;
    timeoutMs?: number;
    backoffMs?: number;
}
export declare function embedText(text: string, _options?: EmbedOptions): Promise<number[]>;
export interface EmbeddedChunk {
    id: string;
    embedding: number[];
}
export declare function embedChunks(chunks: {
    id: string;
    content: string;
}[], options?: EmbedOptions): Promise<EmbeddedChunk[]>;
export declare function getEmbeddingMetrics(): {
    modelLoadTimeMs: number;
    totalEmbeddings: number;
    failedEmbeddings: number;
    averageLatencyMs: number;
};
//# sourceMappingURL=embedder.d.ts.map