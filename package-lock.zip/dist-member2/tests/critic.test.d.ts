export {};
//# sourceMappingURL=critic.test.d.ts.map