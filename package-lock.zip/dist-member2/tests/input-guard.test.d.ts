export {};
//# sourceMappingURL=input-guard.test.d.ts.map