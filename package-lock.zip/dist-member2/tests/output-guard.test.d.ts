export {};
//# sourceMappingURL=output-guard.test.d.ts.map