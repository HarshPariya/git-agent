export {};
//# sourceMappingURL=security-layer.test.d.ts.map