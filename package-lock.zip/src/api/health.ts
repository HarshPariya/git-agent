import type { Request, Response } from "express";
import { env } from "../config/env.js";
import { getDatabaseHealth } from "../db/postgres.js";

export const healthHandler = async (_request: Request, response: Response): Promise<void> => {
  const dbHealth = await getDatabaseHealth();

  response.status(200).json({
    status: dbHealth.status === "healthy" ? "ok" : "degraded",
    environment: env.nodeEnv,
    modules: {
      retrieval: "ready",
      agent: "ready",
    },
    database: {
      status: dbHealth.status,
      latencyMs: dbHealth.latencyMs,
      poolIdleConnections: dbHealth.idleConnections,
      poolTotalConnections: dbHealth.totalConnections,
      waitingCount: dbHealth.waitingCount,
    },
  });
};
