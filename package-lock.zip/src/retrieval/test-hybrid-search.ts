import {
  parseRepository,
} from "../ingestion/parser.js";

import {
  chunkRepository,
} from "../ingestion/chunker.js";

import {
  extractEntities,
} from "../graph/entity-extractor.js";

import {
  extractRelationships,
} from "../graph/relationship-extractor.js";

import {
  buildGraph,
} from "../graph/graph-builder.js";

import {
  pgVectorSearch,
  upsertChunks,
} from "../db/vector-store.js";

import {
  closeDatabase,
  testDatabaseConnection,
} from "../db/postgres.js";

import {
  initializeSchema,
} from "../db/schema.js";

import {
  hybridSearch,
} from "./hybrid-search.js";

async function main() {
  console.log(
    "🔀 Building Persistent Hybrid RAG index...",
  );

  console.log();

  await testDatabaseConnection();
  await initializeSchema();

  const parsedFiles =
    await parseRepository(
      process.cwd(),
    );

  const chunks =
    chunkRepository(
      parsedFiles,
    );

  const entities =
    extractEntities(
      parsedFiles,
    );

  const relationships =
    extractRelationships(
      parsedFiles,
      entities,
    );

  const graph =
    buildGraph(
      entities,
      relationships,
    );

  console.log(
    `✓ Chunks: ${chunks.length}`,
  );

  console.log(
    `✓ Graph nodes: ${graph.nodes.size}`,
  );

  console.log(
    `✓ Graph edges: ${graph.edges.length}`,
  );

  console.log(
    "Persisting vector index to PostgreSQL...",
  );

  await upsertChunks(
    "ai-chatbot",
    chunks,
  );

  const query =
    process.argv
      .slice(2)
      .join(" ") ||
    "Where is normalizeId used?";

  console.log();
  console.log(
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
  );

  console.log(
    `Query: "${query}"`,
  );

  console.log(
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
  );

  console.log();

  const vectorResults =
    await pgVectorSearch(
      query,
      {
        repository: "ai-chatbot",
        limit: 15,
      },
    );

  const results =
    await hybridSearch(
      query,
      graph,
      chunks,
      vectorResults,
      {
        limit: 10,
      },
    );

  results.forEach(
    (result, index) => {
      console.log(
        `${index + 1}. ${result.name}`,
      );

      console.log(
        `   Hybrid: ${result.hybridScore.toFixed(4)}`,
      );

      console.log(
        `   Vector: ${result.vectorScore.toFixed(4)}`,
      );

      console.log(
        `   Graph: ${result.graphScore.toFixed(4)}`,
      );

      console.log(
        `   Sources: ${result.sources.join(" + ")}`,
      );

      if (result.filePath) {
        console.log(
          `   File: ${result.filePath}`,
        );
      }

      if (
        result.graphDepth !==
        undefined
      ) {
        console.log(
          `   Graph depth: ${result.graphDepth}`,
        );
      }

      console.log();
    },
  );
}

main()
  .catch((error) => {
    console.error(
      "Hybrid search failed:",
    );

    console.error(error);

    process.exitCode = 1;
  })
  .finally(async () => {
    await closeDatabase();
  });
